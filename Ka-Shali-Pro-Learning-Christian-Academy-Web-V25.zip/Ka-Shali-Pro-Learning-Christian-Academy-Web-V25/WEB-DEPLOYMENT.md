# KA-SHALI PRO-LEARNING CHRISTIAN ACADEMY — Web Deployment

This folder is the browser website edition based on the supplied V25 project.

## Run locally

1. Install Node.js 20 or newer.
2. Run `npm install`.
3. Run `npm run dev`.
4. Open the local Vite address in Chrome.
5. For production, run `npm run build`.
6. Upload the contents of `dist/` to a static web host or hosting service.

## Production website behavior

- Public school pages work in Chrome without installing the Android app.
- Login, registration and role-based portal screens run in the browser.
- Browser back navigation is handled inside the portal.
- PDFs are opened with the browser's native PDF viewer.
- Images and videos open in the web viewer.
- Downloads use the browser's normal download mechanism.
- Voice notes use the browser microphone permission when the site is served over HTTPS.
- Browser notifications use the Web Notifications API when the user grants permission.
- Uploaded local materials and the demo/local data store use browser storage. This is suitable for a frontend/demo deployment.

## Important production architecture note

This package is a complete web frontend, but it is not yet a multi-device cloud backend. Browser localStorage/IndexedDB is isolated to each browser/device. For real school-wide use where a parent on one phone can submit an application and the principal on another device immediately sees it, the website must be connected to a secure backend/database and object storage. The frontend is structured so that those data/file services can replace the local storage layer without redesigning the public site.
